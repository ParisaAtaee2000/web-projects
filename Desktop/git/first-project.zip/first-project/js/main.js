$(document).ready(function () {
    $(".menu__icon").click(function(){
        $(".menu").css({left:0});
        $(".menu__icon").css({display:"none"})
        $(".close__icon").css({display:"block"})
        
    })
    $(".close__icon").click(function(){
        $(".menu").css({left:"-285px"});
        $(".menu__icon").css({display:"block"})
        $(".close__icon").css({display:"none"})
        
    })
    
})

